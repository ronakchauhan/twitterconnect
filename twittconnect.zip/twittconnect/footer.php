<div class="footer">
      <span>Designed & created by Ronak Chauhan.</span>
    </div>
  </body>
</html>